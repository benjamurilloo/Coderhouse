# Proyecto Final — Automatización con n8n y LLMs
## Análisis automático de mensajes de clientes

---

## Descripción del proyecto

Este workflow procesa automáticamente mensajes de clientes registrados en una hoja de cálculo de Google Sheets. Ante cada nueva fila, un primer LLM (GPT-4.1-mini) clasifica el mensaje como **INTERESADO**, **QUEJA** o **ERROR**. Si es una queja, un segundo LLM (Gemini 2.5 Flash) genera un resumen, las razones del problema y una respuesta sugerida al cliente. El resultado se envía por email vía Gmail.

---

## Estructura del ZIP

```
entrega.zip
├── workflow.json         # Flujo exportado desde n8n (sin credenciales reales)
├── prompts.txt           # Prompts usados en cada nodo LLM
├── README.md             # Este archivo
├── documentacion.pdf     # Descripción técnica, diagramas y rúbrica
└── evidencia/            # Capturas de pantalla de las ejecuciones de prueba
```

---

## Requisitos previos

- n8n instalado (versión 1.x o superior) — https://n8n.io
- Cuenta de Google con acceso a:
  - Google Sheets (para el trigger)
  - Gmail (para las notificaciones)
- API Key de OpenAI con acceso a GPT-4.1-mini
- API Key de Google AI Studio con acceso a Gemini 2.5 Flash

---

## Cómo importar el workflow

1. Abrir n8n en el navegador (por defecto: `http://localhost:5678`)
2. Ir a **Workflows → Import from file**
3. Seleccionar el archivo `workflow.json`
4. El workflow se importa con todos los nodos y conexiones, pero **sin credenciales activas**

---

## Configuración de credenciales

Una vez importado, hay que reconectar cada nodo con credenciales propias. Nunca compartir las API keys reales.

### 1. Google Sheets (Trigger)
- En n8n ir a **Settings → Credentials → New**
- Seleccionar **Google Sheets OAuth2 API**
- Autenticarse con la cuenta de Google que tiene acceso a la hoja
- En el nodo `Cliente nuevo` seleccionar esta credencial
- Cambiar el `documentId` por el ID de tu propia hoja de cálculo
  - El ID está en la URL: `https://docs.google.com/spreadsheets/d/[ESTE_ES_EL_ID]/edit`

**Columnas requeridas en la hoja (exactas):**
| Nombre | Mensaje | Canal | Teléfono | Mail |
|--------|---------|-------|----------|------|

### 2. OpenAI (Clasificador)
- Ir a https://platform.openai.com/api-keys y generar una API key
- En n8n: **Settings → Credentials → New → OpenAI**
- Pegar la API key
- En el nodo `Clasificador de mensajes` seleccionar esta credencial

### 3. Google Gemini (Generador)
- Ir a https://aistudio.google.com/app/apikey y generar una API key
- En n8n: **Settings → Credentials → New → Google PaLM/Gemini**
- Pegar la API key
- En el nodo `Generador de Mail Queja` seleccionar esta credencial

### 4. Gmail (Notificaciones)
- En n8n: **Settings → Credentials → New → Gmail OAuth2**
- Autenticarse con la cuenta de Gmail donde se recibirán las alertas
- En los nodos de mail (`Enviar Alerta Queja`, `Enviar Alerta Interesado`, `Enviar Error Clasificador`, `Enviar Error Generador`) seleccionar esta credencial
- Cambiar el campo `sendTo` por tu dirección de email real en cada nodo

---

## Cómo ejecutar y probar

### Activar el workflow
1. Una vez configuradas las credenciales, hacer clic en el toggle **Active** en la esquina superior derecha
2. El trigger sondeará Google Sheets cada minuto en busca de filas nuevas

### Pruebas reproducibles (mínimo 3 casos)

Agregar estas filas en la hoja de cálculo de Google Sheets para probar los distintos caminos:

**Caso 1 — QUEJA** (debe llegar mail con resumen y respuesta sugerida)
```
Nombre: Ana García
Mensaje: Compré el producto hace dos semanas y llegó roto. El servicio al cliente no me responde y nadie soluciona mi problema.
Canal: WhatsApp
```

**Caso 2 — INTERESADO** (debe llegar mail de lead caliente)
```
Nombre: Luis Pérez
Mensaje: Hola, me gustaría saber los precios y si hacen envíos a Córdoba.
Canal: Email
```

**Caso 3 — ERROR** (debe llegar mail de error de clasificación)
```
Nombre: Test Error
Mensaje: .
Canal: Web
```

### Verificar resultados
- Revisar la bandeja de entrada del email configurado
- En n8n, ir a **Executions** para ver el log de cada ejecución
- Cada ejecución debe mostrar en verde los nodos recorridos según la categoría

---

## Descripción de cada nodo

| Nodo | Tipo | Función |
|------|------|---------|
| Cliente nuevo | Google Sheets Trigger | Detecta nuevas filas en la hoja cada minuto |
| Mapeo de datos | Set | Extrae los campos Nombre y Mensaje para uso posterior |
| Clasificador de mensajes | OpenAI GPT-4.1-mini | Clasifica el mensaje en INTERESADO, QUEJA o ERROR |
| Parseo JSON | Code (JS) | Parsea la respuesta del clasificador; fallback a ERROR si falla |
| Que categoría es? | Switch | Deriva el flujo a la rama correcta según la categoría |
| Generador de Mail Queja | Google Gemini 2.5 Flash | Genera resumen, razones y respuesta sugerida para quejas |
| Error? | IF | Verifica si Gemini respondió correctamente (content exists) |
| Parseo JSON1 | Code (JS) | Parsea la respuesta de Gemini; fallback si el JSON es inválido |
| Enviar Alerta Queja | Gmail | Envía email detallado con análisis de la queja |
| Enviar Alerta Interesado | Gmail | Envía email de alerta de lead caliente |
| Enviar Error Clasificador | Gmail | Notifica si el clasificador o parseo falla |
| Enviar Error Generador | Gmail | Notifica si Gemini falla al generar el análisis |

---

## Manejo de errores

El workflow contempla los siguientes escenarios de fallo:

- **GPT devuelve JSON inválido:** el nodo `Parseo JSON` tiene un `try/catch` que asigna la categoría `ERROR`, derivando el flujo al mail de alerta.
- **Gemini falla o devuelve respuesta vacía:** el nodo tiene `onError: continueRegularOutput`. El nodo `Error?` verifica si `content` existe; si no, deriva a `Enviar Error Generador`.
- **Gemini devuelve JSON malformado:** el nodo `Parseo JSON1` tiene `try/catch` que asigna valores de error por defecto en lugar de romper el flujo.

---

## Notas de seguridad

- Las credenciales reales **no están incluidas** en el `workflow.json` entregado.
- Los IDs de credenciales en el JSON son placeholders (`YOUR_OPENAI_CREDENTIAL_ID`, etc.).
- Al importar, n8n pedirá reconectar cada credencial manualmente.
- No subir el `workflow.json` con credenciales reales a repositorios públicos.
