# Detector de personajes Simpson

Este workflow automatiza la detección de personajes de la familia Simpson utilizando la API pública The Simpsons API.

El proceso se inicia con un **Schedule Trigger** que ejecuta el workflow periódicamente. Luego un nodo **Code** genera un ID aleatorio de personaje y se consulta la API mediante **HTTP Request**.

El nodo **IF** evalúa si el nombre del personaje contiene "Simpson". Si la condición se cumple, los datos se normalizan con un nodo **Set**.

Finalmente, el workflow envía una **notificación automática por Gmail** con la información del personaje y su imagen.

Se aplicaron buenas prácticas como uso de credenciales seguras en n8n, normalización de datos y monitoreo mediante logs de ejecución.